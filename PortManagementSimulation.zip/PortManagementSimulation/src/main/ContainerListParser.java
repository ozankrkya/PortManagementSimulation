package main;

import java.util.ArrayList;
import java.util.Collections;

import containers.Container;
/**
 * This classes just consists of a static method that is used for parsing the container lists to four ArrayLists according to their type, 
 * Basic, Heavy, Refrigerated and Liquid.
 * @author Ozan Oytun Karakaya
 *
 */
public class ContainerListParser {
	/**
	 * This method is written in order to create the desired output easily, also it sorts the given ArrayList in the beginning.
	 * @param cList is the ArrayList of containers to be parsed to four (Basic, Heavy, Refrigerated, Liquid - in this order).
	 * @return an ArrayList of ArrayLists of containers(always has four elements, if one type has no instance in cList then its ArrayList contains no elements.)
	 */
	public static ArrayList<ArrayList<Container>> containerListParser(ArrayList<Container> cList){
		Collections.sort(cList);
		ArrayList<Container> bConts= new ArrayList<Container>();
		ArrayList<Container> hConts= new ArrayList<Container>();
		ArrayList<Container> rConts= new ArrayList<Container>();
		ArrayList<Container> lConts= new ArrayList<Container>();
		for (Container cont : cList) {
			if (cont.getType().equals("Basic")) {
				bConts.add(cont);
			}
			else if (cont.getType().equals("Heavy")){
				hConts.add(cont);
			}
			else if (cont.getType().equals("Refrigerated")) {
				rConts.add(cont);
			}
			else if (cont.getType().equals("Liquid")) {
				lConts.add(cont);
			}
		}
		ArrayList<ArrayList<Container>> finalList = new ArrayList<ArrayList<Container>>();
		finalList.add(bConts);
		finalList.add(hConts);
		finalList.add(rConts);
		finalList.add(lConts);
		return finalList;
	}
}
