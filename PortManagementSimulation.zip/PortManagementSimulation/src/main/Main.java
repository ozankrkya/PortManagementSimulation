
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;

import containers.*;
import ports.Port;
import ships.Ship;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
			
		Scanner buffer = new Scanner(new File(args[0]));
		PrintStream out = new PrintStream(new File(args[1]));
		/**
		 * ArrayList of all of the ports in the simulation.
		 */
		ArrayList<Port> ports = new ArrayList<Port>();
		/**
		 * ArrayList of all of the ships in the simulation.
		 */
		ArrayList<Ship> ships = new ArrayList<Ship>();
		/**
		 * ArrayList of all of the containers in the simulation.
		 */
		ArrayList<Container> allContainers = new ArrayList<Container>();
		
		/**
		 * Reads the given input file with Scanner object called buffer in this code.
		 * Gives IDs to ports, ships and containers beginning with zero and incrementing by one whenever an object of that class is created.
		 * Reads the loading, unloading, sailing and refueling processes from input file and does necessary actions.
		 */
		int currentContainerID = 0;
		int currentShipID = 0;
		int currentPortID = 0;
		int N = buffer.nextInt();
		for (int i=0; i < N; i++) {
			int processNumber = buffer.nextInt();
			if (processNumber == 1) {
				int contPortID = buffer.nextInt();
				int contWeight = buffer.nextInt();
				if (!buffer.hasNextInt()) {
					String RorL = buffer.next();;
					if (RorL.equals("R")) {;
						RefrigeratedContainer RCont = new RefrigeratedContainer(currentContainerID, contWeight);
						allContainers.add(RCont);
						ports.get(contPortID).getContainers().add(RCont);
						currentContainerID += 1;
					}
					else {
						LiquidContainer LCont = new LiquidContainer(currentContainerID, contWeight);
						allContainers.add(LCont);
						ports.get(contPortID).getContainers().add(LCont);
						currentContainerID += 1;
					}
				}
				else {
					if (contWeight <= 3000) {
						BasicContainer BCont = new BasicContainer(currentContainerID, contWeight);
						allContainers.add(BCont);
						ports.get(contPortID).getContainers().add(BCont);
						currentContainerID += 1;
					}
					else {
						HeavyContainer HCont = new HeavyContainer(currentContainerID, contWeight);
						allContainers.add(HCont);
						ports.get(contPortID).getContainers().add(HCont);
						currentContainerID += 1;
					}
				}
			}
			else if (processNumber == 2) {
				int initialPortID = buffer.nextInt();
				int pTotalWeightCapacity = buffer.nextInt();
				int pMaxNumberOfAllContainers = buffer.nextInt();
				int pMaxNumberOfHeavyContainers = buffer.nextInt();
				int pMaxNumberOfRefrigeratedContainers = buffer.nextInt();
				int pMaxNumberOfLiquidContainers = buffer.nextInt();
				double pFuelConsumptionPerKM = buffer.nextDouble();
				Ship s = new Ship(currentShipID, ports.get(initialPortID), pTotalWeightCapacity, pMaxNumberOfAllContainers, pMaxNumberOfHeavyContainers, 
						pMaxNumberOfRefrigeratedContainers, pMaxNumberOfLiquidContainers, pFuelConsumptionPerKM);
				ships.add(s);
				currentShipID += 1;
			}
			else if (processNumber == 3) {
				double pX = buffer.nextDouble();
				double pY = buffer.nextDouble();
				Port p = new Port(currentPortID, pX, pY);
				ports.add(p);
				currentPortID += 1;
			}
			else if (processNumber == 4) {
				int loadedShipID = buffer.nextInt();
				int loadingContainerID = buffer.nextInt();
				if (ships.get(loadedShipID).load(allContainers.get(loadingContainerID))) {
					;
				}
			}
			else if (processNumber == 5) {
				int unLoadedShipID = buffer.nextInt();
				int unLoadingContainerID = buffer.nextInt();
				if (ships.get(unLoadedShipID).unLoad(allContainers.get(unLoadingContainerID))) {
					;
				}
			}
			else if (processNumber == 6) {
				int travellingShipID = buffer.nextInt();
				int destinationPortID = buffer.nextInt();
				if(ships.get(travellingShipID).sailTo(ports.get(destinationPortID))) {
					;
				}
			}
			else if (processNumber == 7) {
				int reFueledShipID = buffer.nextInt();
				double fuelAmount = buffer.nextDouble();
				ships.get(reFueledShipID).reFuel(fuelAmount);
			}
		}
		
		/**
		 * Prints the desired output in the desired way, ports and their current container lists. Then prints the ships in the ports' current ArrayList
		 * with their container ArrayLists.
		 * Does same thing for every port in the simulation.
		 */
		for (Port p : ports) {
			out.printf("Port %d: (%.2f, %.2f)\n",p.getID(),p.getX(),p.getY());
			ArrayList<ArrayList<Container>> portsConts = ContainerListParser.containerListParser(p.getContainers());
			for (int i = 0; i < 4; i++){
				if(i == 0 && portsConts.get(i).size()>0) {
					out.print("  BasicContainer: ");
					for (Container c : portsConts.get(i)) {
						out.print(c.getID()+" ");
					}
					out.print("\n");
				}
				else if(i == 1 && portsConts.get(i).size()>0) {
					out.print("  HeavyContainer: ");
					for (Container c : portsConts.get(i)) {
						out.print(c.getID()+" ");
					}
					out.print("\n");
				}
				else if(i == 2 && portsConts.get(i).size()>0) {
					out.print("  RefrigeratedContainer: ");
					for (Container c : portsConts.get(i)) {
						out.print(c.getID()+" ");
					}
					out.print("\n");
				}
				else if(i == 3 && portsConts.get(i).size()>0) {
					out.print("  LiquidContainer: ");
					for (Container c : portsConts.get(i)) {
						out.print(c.getID()+" ");
					}
					out.print("\n");
				}
					
			}
			Collections.sort(p.getCurrent());
			for (Ship s : p.getCurrent()) {
				out.printf("  Ship %d: %.2f\n",s.getID(),s.getFuel());
				ArrayList<ArrayList<Container>> shipsConts = ContainerListParser.containerListParser(s.getCurrentContainers());
				for (int i = 0; i < 4; i++){
					if(i == 0 && shipsConts.get(i).size()>0) {
						out.print("    BasicContainer: ");
						for (Container c : shipsConts.get(i)) {
							out.print(c.getID()+" ");
						}
						out.print("\n");
					}
					else if(i == 1 && shipsConts.get(i).size()>0) {
						out.print("    HeavyContainer: ");
						for (Container c : shipsConts.get(i)) {
							out.print(c.getID()+" ");
						}
						out.print("\n");
					}
					else if(i == 2 && shipsConts.get(i).size()>0) {
						out.print("    RefrigeratedContainer: ");
						for (Container c : shipsConts.get(i)) {
							out.print(c.getID()+" ");
						}
						out.print("\n");
					}
					else if(i == 3 && shipsConts.get(i).size()>0) {
						out.print("    LiquidContainer: ");
						for (Container c : shipsConts.get(i)) {
							out.print(c.getID()+" ");
						}
						out.print("\n");
					}
				}
			}
			
		}
		buffer.close();
		out.close();
	}
	
}



//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

