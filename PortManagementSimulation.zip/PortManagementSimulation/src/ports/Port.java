
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package ports;

import interfaces.IPort;
import ships.Ship;
import java.util.ArrayList;
import containers.Container;


/**
 * This class implements Ports which ships can be loaded containers and unload containers to. 
 * @author Ozan Karakaya
 *
 */
public class Port implements IPort {
	/**
	 * The ID of the port
	 */
	private int ID;
	/**
	 * The X coordinate of the port's location.
	 */
	private double X;
	/**
	 * The Y coordinate of the port's location.
	 */
	private double Y;
	/**
	 * Array List which consists of the containers in the port.
	 */
	public ArrayList<Container> containers = new ArrayList<Container>(); 
	/**
	 * Array List which consists of the ships which are currently in the port.
	 */
	private ArrayList<Ship> history = new ArrayList<Ship>();
	/**
	 * Array List which consists of the ships have left from this port.
	 */
	private ArrayList<Ship> current = new ArrayList<Ship>();
	/**
	 * Constructor which takes the ID of the port and the coordinates of port's location.
	 * @param ID the ID of the Port
	 * @param X the X coordinate of the port's location.
	 * @param Y the Y coordinate of the port's location.
	 */
	public Port(int ID, double X, double Y) {
		this.ID = ID;
		this.X = X;
		this.Y = Y;
	}
	/**
	 * Calculates the distance between two ports with their coordinates.
	 * @param other the other port that the calculation of the distance between this port to be done.
	 * @return the distance between the other port and this port with a double value 
	 */
	public final double getDistance(Port other) {
		double XDifferences = this.getX() - other.getX();
		double YDifferences = this.getY() - other.getY();
		return Math.sqrt(XDifferences*XDifferences + YDifferences*YDifferences);
	}
	/**
	 * This method adds the incoming ship to the Array List which current ships at the port is held.
	 * Sets incoming ship's current port field to this port.
	 * @param s takes the ship which is arriving to this port.
	 */
	public final void incomingShip(Ship s) {
		current.add(s);
	}
	/** 
	 * This method adds the outgoing ship to the Array List which left ships from the port is held. Also removes the ship outgoing 
	 * from the current ship Array List.
	 * @param s takes the ship which is leaving this port.
	 */
	public final void outgoingShip(Ship s) {
		current.remove(current.indexOf(s));
		if (!history.contains(s)) {
			history.add(s);
		}
	}
	/**
	 * 
	 * @return the ID of the port.
	 */
	public int getID() {
		return this.ID;
	}
	/**
	 * 
	 * @return the X coordinate of the port.
	 */
	public double getX() {
		return this.X;
	}
	/**
	 * 
	 * @return the Y coordinate of the port.
	 */
	public double getY() {
		return this.Y;
	}
	/**
	 * @return the ArrayList of containers which is currently at the port.
	 */
	public ArrayList<Container> getContainers(){
		return this.containers;
	}
	/**
	 * 
	 * @return the Array List of the ships which have left from the port.
	 */
	public ArrayList<Ship> getHistory(){
		return this.history;
	}
	/**
	 * 
	 * @return the Array List of the ships which is currently at the port.
	 */
	public ArrayList<Ship> getCurrent(){
		return this.current;
	}
	
}

//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

