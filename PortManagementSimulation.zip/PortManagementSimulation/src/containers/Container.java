
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package containers;
/**
 * This class implements an abstract class for containers that basic and heavy container types will be inherited from this class.
 * @author Ozan Oytun Karakaya
 */
public abstract class Container implements Comparable<Container> {
	/**
	 * the ID field of the container
	 */
	protected int ID;
	/**
	 * the weight field of the container
	 */
	protected int weight;
	/**
	 * the type of the container (Basic, Heavy, Refrigerated or Liquid).
	 */
	protected String type;
	
	/**
	 * This method constructs a container by taking ID and weight parameters. It is overridden in subclasses.
	 * @param ID the ID of the container.
	 * @param weight the weight of the container.
	 */
	public Container(int ID ,int weight) {
		this.ID = ID;
		this.weight = weight;
	}
	
	/**
	 * This abstract method is overridden in subclasses differently in each other due to different fuel consumptions.
	 * Thus i wrote this class as abstract.
	 * @return fuel consumption per KM for the container its self when it's loaded to a ship.
	 */
	public abstract double consumption();
	
	/**
	 * @param other takes the container to be checked with.
	 * @return true if this container and the other is same.
	 * @return false if this container and the other is not same.
	 */
	public boolean equals(Container other) {
		if (this.ID == other.getID() && this.weight == other.getWeight() && 
				this.type == other.getType()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	/**
	 * This method is overridden due to sorting of the container lists.
	 *@param other takes the other container to be compared with.
	 *@return 1 if ID of this container is bigger than the other's.
	 *@return -1 if ID of this container is smaller than the other's.
	 *@return 0 if ID of this container is equals to the other's.
	 */
	public int compareTo(Container other) {
		if (other instanceof Container) {
			if (this.ID > other.getID()) {
				return 1;
			}
			else if (this.ID < other.getID()) {
				return -1;
			}
			else {
				return 0;
			}
		}
		return 0;
	}
	/**
	 * 
	 * @return the type of container.
	 */
	public String getType() {
		return type;
	}
	/**
	 * 
	 * @param type sets the type of container.
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * 
	 * @return the ID of the container.
	 */
	public int getID() {
		return this.ID;
	}
	/**
	 * 
	 * @return the weight of the container.
	 */
	public int getWeight() {
		return this.weight;
	}
	
}

//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

