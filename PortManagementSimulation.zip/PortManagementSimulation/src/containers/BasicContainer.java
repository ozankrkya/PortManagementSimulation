
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package containers;
/**
 * This class implements the basic container type class. It is inherited from the Container class.
 * @author Ozan Oytun Karakaya
 *
 */
public class BasicContainer extends Container {
	/**
	 * Overridden constructor from the parent class due to specify the type.
	 * @param ID the ID of the container.
	 * @param weight the weight of the container.
	 * The type field is initialized to Basic.
	 */
	public BasicContainer(int ID, int weight) {
		super(ID, weight);
		this.type = "Basic";
	}
	/**
	 * Overridden consumption method with specific fuel consumption per KM for basic containers.
	 * @return the fuel consumption per KM for the container which is calculated with its weight when loaded to a ship.
	 */
	@Override	
	public double consumption() {
		return 2.50 * (double)this.weight;
	}
}



//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

