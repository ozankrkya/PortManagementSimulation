
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package containers;
/**
 * This class implements the heavy container type class. It is inherited from the Container class.
 * Also it is the parent class for the Refrigerated Container and the Liquid Container classes.
 * @author Ozan Oytun Karakaya
 *
 */
public class HeavyContainer extends Container {
	/**
	 * Overridden constructor from the parent class due to specify the type.
	 * @param ID the ID of the container.
	 * @param weight the weight of the container.
	 * The type field is initialized to Heavy.
	 */
	public HeavyContainer(int ID, int weight) {
		super(ID, weight);
		this.type = "Heavy";
	}
	/**
	 * Overridden consumption method with specific fuel consumption per KM for heavy containers.
	 * @return the fuel consumption per KM for the container which is calculated with its weight when loaded to a ship.
	 */
	@Override
	public double consumption() {
		return (double)this.weight * 3.00;
	}
}



//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

