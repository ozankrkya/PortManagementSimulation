
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

package ships;

import ports.Port;
import interfaces.IShip;
import containers.*;
import java.util.*;
/**
 * This class implements the ships that travels between the ports, carries containers and unload them to the ports and gets loaded containers from the ports.
 * Also this ships can be refueled.
 * @author Ozan Oytun Karakaya
 *
 */
public class Ship implements IShip, Comparable<Ship> {
	/**
	 * The ID of the ship.
	 */
	private int ID;
	/**
	 * The current fuel amount that the ship has. Initialized to 0 when ship is created.
	 */
	private double fuel;
	/**
	 * The current port that the ship is located at.
	 */
	private Port currentPort;
	/**
	 * The total weight capacity that the ship can carry.
	 */
	private int totalWeightCapacity;
	/**
	 * The maximum number of all types of containers that the ship can hold/carry.
	 */
	private int maxNumberOfAllContainers;
	/**
	 * The maximum number of heavy containers (including heavy, refrigerated and the liquid type) that the ship can hold/carry.
	 */
	private int maxNumberOfHeavyContainers;
	/**
	 * The maximum number of refrigerated containers that the ship can hold/carry.
	 */
	private int maxNumberOfRefrigeratedContainers;
	/**
	 * The maximum number of liquid containers that the ship can hold/carry.
	 */
	private int maxNumberOfLiquidContainers;
	/**
	 * The ship's fuel consumption per KM just due to its own structure without containers.
	 */
	private double fuelConsumptionPerKM;
	/**
	 * ArrayList which consists of the containers that the ship is holding in it.
	 */
	private ArrayList<Container> currentContainers = new ArrayList<Container>();
	/**
	 * Constructor for the ship instances.
	 * @param ID the ID of the ship.
	 * @param p the port where the ship is at currently.
	 * @param totalWeightCapacity The total weight capacity that the ship can carry.
	 * @param maxNumberOfAllContainers The maximum number of all types of containers that the ship can hold/carry.
	 * @param maxNumberOfHeavyContainers The maximum number of heavy containers (including heavy, refrigerated and the liquid type) that the ship can hold/carry.
	 * @param maxNumberOfRefrigeratedContainers The maximum number of refrigerated containers that the ship can hold/carry.
	 * @param maxNumberOfLiquidContainers The maximum number of liquid containers that the ship can hold/carry.
	 * @param fuelConsumptionPerKM The ship's fuel consumption per KM just due to its own structure without containers.
	 */
	public Ship (int ID, Port p, int totalWeightCapacity, int maxNumberOfAllContainers, int maxNumberOfHeavyContainers,
	int maxNumberOfRefrigeratedContainers, int maxNumberOfLiquidContainers, double fuelConsumptionPerKM) {
		this.setID(ID);
		this.setFuel(0);
		this.setCurrentPort(p);
		this.setTotalWeightCapacity(totalWeightCapacity);
		this.setMaxNumberOfAllContainers(maxNumberOfAllContainers);
		this.setMaxNumberOfHeavyContainers(maxNumberOfHeavyContainers);
		this.setMaxNumberOfRefrigeratedContainers(maxNumberOfRefrigeratedContainers);
		this.setMaxNumberOfLiquidContainers(maxNumberOfLiquidContainers);
		this.setFuelConsumptionPerKM(fuelConsumptionPerKM);
		p.getCurrent().add(this);
	}

	/**
	 * 
	 * @return the current containers ArrayList after sorting it with the usage of Collections class.
	 */
	public ArrayList<Container> getCurrentContainers(){
		Collections.sort(this.currentContainers);
		return this.currentContainers;
	}
	/**
	 * Overridden compareTo method from Comparable Interface in order to compare the ship objects by their IDs.
	 * @param other the ship that to be compared with this.
	 * @return 1 if ID of this ship is bigger than the other ship's id.
	 * @return -1 if ID of this ship is smaller than the other ship's id.
	 * @return 0 if two ships' IDs are equal.
	 */
	public int compareTo(Ship other) {
		if(this.getID() > other.getID()) {
			return 1;
		}
		else if (this.getID() < other.getID()) {
			return -1;
		}
		else {
			return 0;
		}
	}
	/**
	 * This methods calculates the total fuel consumption of this ship and then gets the distance to given port from current port. 
	 * Then calculates the fuel requirement for sailing process and checks if this ship has enough fuel.
	 * @param p the port that to be sailed to.
	 * @return true if ship can travel to given port, which means has enough fuel.
	 * @return false if has not enough fuel.
	 */
	public final boolean sailTo(Port p) {
		double fuelNeeded = this.fuelCalculatorToPort(p);
		if (fuelNeeded > this.getFuel()) {
			return false;
		}
		else {
			this.setFuel(this.getFuel()-fuelNeeded);
			this.getCurrentPort().outgoingShip(this);
			p.incomingShip(this);
			this.setCurrentPort(p);
			return true;
		}
	}
	/**
	 * @param p the port to be sailed to.
	 * @return fuel needed to sail to given port p.
	 */
	public double fuelCalculatorToPort(Port p) {
		double consumptionFromLoadsPerKM = 0;
		for (int i =0; i<this.getCurrentContainers().size(); i++) {
			consumptionFromLoadsPerKM += currentContainers.get(i).consumption();
		}
		double totalConsumptionPerKM = consumptionFromLoadsPerKM + this.getFuelConsumptionPerKM();
		double distance = this.currentPort.getDistance(p);
		double fuelNeeded = distance * totalConsumptionPerKM;
		return fuelNeeded;
	}
	/**
	 * Adds given amount of fuel to the ship.
	 * @param amount of fuel to be added.
	 */
	@Override 
	public void reFuel(double newFuel) {
		this.setFuel(this.getFuel() + newFuel);
	}
	/**
	 * This methods controls the loading process of given container is possible or not.
	 * Checks the type of container and checks if ship has enough place and weight capacity to carry that type of container and the weight of it.
	 * Also checks that if given container is in the current port of the ship.
	 * @param cont is the container to be loaded.
	 * @return true if loading is possible
	 * @return false if loading is not possible according to given conditions.
	 */
	@Override
	public final boolean load(Container cont) {
		
		if (!this.currentPort.getContainers().contains(cont)) {
			return false;
		}
		
		int currentLoadWeight = 0;
		int currentHeavyContNum = 0;
		int currentRefrigeratedContNum = 0;
		int currentLiquidContNum = 0;
		for(int i= 0; i < this.currentContainers.size(); i++) {
			if (currentContainers.get(i).getType() == "Basic") {
				currentLoadWeight += currentContainers.get(i).getWeight();
			}
			else if (currentContainers.get(i).getType() == "Heavy") {
				currentLoadWeight += currentContainers.get(i).getWeight();
				currentHeavyContNum +=1;
			}
			else if (currentContainers.get(i).getType() == "Refrigerated") {
				currentLoadWeight += currentContainers.get(i).getWeight();
				currentRefrigeratedContNum +=1;
				currentHeavyContNum +=1;
			}
			else if (currentContainers.get(i).getType() == "Liquid") {
				currentLoadWeight += currentContainers.get(i).getWeight();
				currentLiquidContNum +=1;
				currentHeavyContNum +=1;
			}
		}
		
		if (cont.getWeight() + currentLoadWeight <= this.totalWeightCapacity && this.currentContainers.size() < this.maxNumberOfAllContainers) {
			if (cont.getType() == "Basic") {
				this.loadToShip(cont);
				return true;
				}
			else{
				if (currentHeavyContNum < this.maxNumberOfHeavyContainers) {
					if (cont.getType() == "Refrigerated" && currentRefrigeratedContNum < this.maxNumberOfRefrigeratedContainers) {
						this.loadToShip(cont);
						return true;
					}
					else if (cont.getType() == "Liquid" && currentLiquidContNum < this.maxNumberOfLiquidContainers) {
						this.loadToShip(cont);
						return true;
					}
					else if (cont.getType() == "Heavy") {
						this.loadToShip(cont);
						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
			}
		}
		else {
			return false;
		}
	}
	
	/**
	 * @param cont takes the container object to be unloaded from the ship itself
	 * @return true if the container object is in the ship itself
	 * @return false if the container object is in the ship itself
	 */
	
	public final boolean unLoad(Container cont) {
		if (this.currentContainers.contains(cont)) {
			this.unLoadFromShip(cont);
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * adds given container to the ships current container ArrayList and removes the same container from the port's ArrayList of current containers.
	 * @param cont is the container to be loaded.
	 */
	public final void loadToShip(Container cont) {
			this.currentContainers.add(cont);
			int index = this.currentPort.getContainers().indexOf(cont);
			this.currentPort.getContainers().remove(index);
	}
	/**
	 * Unloads the container where the ships is currently at. Removes the container from the ship's current container ArrayList and adds to the
	 * ship's current port's container ArrayList.
	 * @param cont the container is to be unloaded from ship to port.
	 */
	public final void unLoadFromShip(Container cont) {
			this.currentPort.getContainers().add(cont);
			int index = this.currentContainers.indexOf(cont);
			this.currentContainers.remove(index);
	}

	/**
	 * @return the currentPort
	 */
	public Port getCurrentPort() {
		return currentPort;
	}

	/**
	 * @param currentPort the currentPort to set
	 */
	public void setCurrentPort(Port currentPort) {
		this.currentPort = currentPort;
	}

	/**
	 * @return the iD
	 */
	public int getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	 * @return the fuel
	 */
	public double getFuel() {
		return fuel;
	}

	/**
	 * @param fuel the fuel to set
	 */
	public void setFuel(double fuel) {
		this.fuel = fuel;
	}

	/**
	 * @return the totalWeightCapacity
	 */
	public int getTotalWeightCapacity() {
		return totalWeightCapacity;
	}

	/**
	 * @param totalWeightCapacity the totalWeightCapacity to set
	 */
	public void setTotalWeightCapacity(int totalWeightCapacity) {
		this.totalWeightCapacity = totalWeightCapacity;
	}
	
	/**
	 * @return the maxNumberOfAllContainers
	 */
	public int getMaxNumberOfAllContainers() {
		return maxNumberOfAllContainers;
	}

	/**
	 * @param maxNumberOfAllContainers the maxNumberOfAllContainers to set
	 */
	public void setMaxNumberOfAllContainers(int maxNumberOfAllContainers) {
		this.maxNumberOfAllContainers = maxNumberOfAllContainers;
	}

	/**
	 * @return the maxNumberOfHeavyContainers
	 */
	public int getMaxNumberOfHeavyContainers() {
		return maxNumberOfHeavyContainers;
	}

	/**
	 * @param maxNumberOfHeavyContainers the maxNumberOfHeavyContainers to set
	 */
	public void setMaxNumberOfHeavyContainers(int maxNumberOfHeavyContainers) {
		this.maxNumberOfHeavyContainers = maxNumberOfHeavyContainers;
	}

	/**
	 * @return the maxNumberOfRefrigeratedContainers
	 */
	public int getMaxNumberOfRefrigeratedContainers() {
		return maxNumberOfRefrigeratedContainers;
	}

	/**
	 * @param maxNumberOfRefrigeratedContainers the maxNumberOfRefrigeratedContainers to set
	 */
	public void setMaxNumberOfRefrigeratedContainers(int maxNumberOfRefrigeratedContainers) {
		this.maxNumberOfRefrigeratedContainers = maxNumberOfRefrigeratedContainers;
	}

	/**
	 * @return the maxNumberOfLiquidContainers
	 */
	public int getMaxNumberOfLiquidContainers() {
		return maxNumberOfLiquidContainers;
	}

	/**
	 * @param maxNumberOfLiquidContainers the maxNumberOfLiquidContainers to set
	 */
	public void setMaxNumberOfLiquidContainers(int maxNumberOfLiquidContainers) {
		this.maxNumberOfLiquidContainers = maxNumberOfLiquidContainers;
	}

	/**
	 * @return the fuelConsumptionPerKM
	 */
	public double getFuelConsumptionPerKM() {
		return fuelConsumptionPerKM;
	}

	/**
	 * @param fuelConsumptionPerKM the fuelConsumptionPerKM to set
	 */
	public void setFuelConsumptionPerKM(double fuelConsumptionPerKM) {
		this.fuelConsumptionPerKM = fuelConsumptionPerKM;
	}
	
}


//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

